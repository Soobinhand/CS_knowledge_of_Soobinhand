package DesignPattern.Midterm;

public class CombinationPizza extends AbstractPizza{
    private AbstractPizza abstractPizza;

    @Override
    public double weight() {
        return 300;
    }

    public String toString(){
        return abstractPizza.toString() + "CombinationPizza";
    }
}
