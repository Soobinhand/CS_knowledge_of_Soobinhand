package DesignPattern.Midterm;

public class CheesePizza extends AbstractPizza{

    private AbstractPizza abstractPizza;

    @Override
    public double weight() {
        return 280;
    }



    public String toString(){
        return abstractPizza.toString() + "CheesePizza";
    }
}
