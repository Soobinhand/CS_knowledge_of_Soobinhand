package DesignPattern.Midterm;

public class ExtraCheeseTopping extends AbstractTopping {



    public ExtraCheeseTopping(AbstractPizza abstractPizza) {
        toppingName = ", extra cheese topping";
        this.abstractPizza = abstractPizza;
    }

    @Override
    public double weight() {
        return abstractPizza.weight() + 40;
    }


}
