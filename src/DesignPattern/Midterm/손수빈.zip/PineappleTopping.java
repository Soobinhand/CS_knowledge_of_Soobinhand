package DesignPattern.Midterm;

public class PineappleTopping extends AbstractTopping {

    public PineappleTopping(AbstractPizza abstractPizza) {
        toppingName = ", PineappleTopping";

        this.abstractPizza = abstractPizza;
    }

    @Override
    public double weight() {
        return abstractPizza.weight() + 45;
    }
}
